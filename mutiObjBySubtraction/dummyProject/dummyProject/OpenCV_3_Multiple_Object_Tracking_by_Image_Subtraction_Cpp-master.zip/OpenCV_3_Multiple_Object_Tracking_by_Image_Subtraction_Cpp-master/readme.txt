The video pretty much explains it all:
https://www.youtube.com/watch?v=A4UDOAOTRdw